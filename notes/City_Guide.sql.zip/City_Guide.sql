-- phpMyAdmin SQL Dump
-- version 4.2.12deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 25. Jun 2015 um 23:59
-- Server Version: 5.5.43-0+deb8u1
-- PHP-Version: 5.6.9-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `City_Guide`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Guide`
--

CREATE TABLE IF NOT EXISTS `Guide` (
`GuideID` int(11) NOT NULL,
  `Titel` varchar(50) DEFAULT NULL,
  `Streetname` varchar(50) DEFAULT NULL,
  `Bus_stop` varchar(30) DEFAULT NULL,
  `Google_Maps` varchar(100) DEFAULT NULL,
  `Abstract` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Guide`
--

INSERT INTO `Guide` (`GuideID`, `Titel`, `Streetname`, `Bus_stop`, `Google_Maps`, `Abstract`) VALUES
(1, 'Little Tokyo', 'Immermann Str.', 'Immermann Str.', 'not', 'Die Immermannstra&szlig;e ist die Hauptschlagader der japanischen Community in D&uuml;sseldorf. \nHier befinden sich nicht nur das Japan-Center mit dem Generalkonsulat und Nikko-Hotel. \nAuf der Immermannstra&szlig;e und ... \n'),
(2, 'K&ouml;nigsallee', 'K&ouml;nigsallee', 'Steinstrasse, K&ouml;nigsallee', 'not', 'Die K&ouml;nigsallee, liebevoll kurz &quot;K&Ouml;&quot; genannt, \nist anregendes Shoppingparadies und aufregende Ausgehmeile in einem, \nLaufsteg der Modemutigen und Rastplatz f&uuml;r Genie&szlig;er. \nDie unnachahmliche Kombination aus schwelgerischem Luxus und ...'),
(3, 'Altstadt', 'Keine genauen Angaben m&ouml;glich', 'Heinrich-Heine Allee', 'not', 'Ein wundersch&ouml;ner Platz im Herzen der Altstadt. \nEin Highlight ist die &quot;D&uuml;sseldorfer Treppe&quot;, \neine Art Panorama-Trib&uuml;ne mit Blick auf den Rhein. \nHier gibt es h&auml;ufig Street-Art, Stra&szlig;enmusiker, Akrobaten etc. zu bestaunen....'),
(4, 'Burgplatz', 'Heinrich-Heine Allee', 'Heinrich-Heine Allee', 'not', 'Der Burgplatz ist so etwas wie die gute Stube und ein Dreh- und Angelpunkt der Stadt. \nHier ist immer etwas los.Im Fr&uuml;hsommer die Jazzralley, \nOpen-Air-Kino, um den 14. Juni erobern franz&ouml;sische Oldtimer den Platz am Frankreich-Tag, \n...'),
(5, 'Rheinuferpromenade', '-', '-', 'not', 'Die Rheinuferpromenade verbindet die traditionsreiche Altstadt mit dem modernen \nMedienHafen und wird ges&auml;umt von Cafés und Bars. Von hier aus lassen sich die vorbei \nziehenden Rheinschiffe entspannt ...'),
(6, 'Hauptbahnhof', '-', 'D&uuml;sseldorf Hbf', 'not', 'Der D&uuml;sseldorfer D&uuml;sseldorfer geh&ouml;rt mit ca. 250.000 Reisenden pro Tag \nzur Top Ten der meistfrequentierten Bahnh&ouml;fe Deutschlands. \nMan kommt schnell mit der Bahn zum jeden Ort.'),
(7, 'Hofgarten', '-', 'Janwellenplatz', 'not', 'Die gr&uuml;ne Lunge mitten in der dichtbebauten City. \nWegen seiner Vielf&auml;ltigkeit ist der Hofgarten ein beliebtes Ziel f&uuml;r einen \nerholsamen Spaziergang. Die Vielf&auml;ltigkeit verdankt der Park den unterschiedlichen \nAuffassungen &uuml;ber...'),
(8, 'Flughafen', '-', 'Flughafen: Terminal A,B,C', 'not', 'Der D&uuml;sseldorf Airport ist der drittgr&ouml;&szlig;te Flughafen Deutschlands und wichtigste \ninternationale Drehkreuz des Landes NRW');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Stichwort`
--

CREATE TABLE IF NOT EXISTS `Stichwort` (
`StichwortID` int(11) NOT NULL,
  `Keywords` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Stichwort`
--

INSERT INTO `Stichwort` (`StichwortID`, `Keywords`) VALUES
(1, 'Rheinuferpromenade'),
(2, 'Altstadt'),
(3, 'Medienhafen'),
(4, 'Caffees'),
(5, 'Bars'),
(6, 'Rheinschiffe'),
(7, 'Bahn'),
(8, 'Zug'),
(9, 'Hofgarten'),
(10, 'Park'),
(11, 'Airport'),
(12, 'Flughafen'),
(13, 'Burgplatz'),
(14, 'Angelpunkt'),
(15, 'Jazz-Ralley'),
(16, 'Panorama'),
(17, 'Rhein'),
(18, 'Street-Art'),
(19, 'K&ouml;nigsallee'),
(20, 'Shopping'),
(21, 'Luxus'),
(22, 'Japan-Center'),
(23, 'Immermannstra&szlig;e'),
(24, 'Generalkonsultat'),
(25, 'Restaurants'),
(26, 'Gastronomie');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Suche`
--

CREATE TABLE IF NOT EXISTS `Suche` (
  `GuideID` int(11) NOT NULL,
  `StichwortID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Suche`
--

INSERT INTO `Suche` (`GuideID`, `StichwortID`) VALUES
(5, 1),
(3, 2),
(5, 3),
(3, 4),
(5, 4),
(3, 5),
(5, 5),
(5, 6),
(6, 7),
(6, 8),
(7, 9),
(7, 10),
(8, 11),
(8, 12),
(4, 13),
(4, 14),
(4, 15),
(3, 16),
(5, 16),
(3, 17),
(5, 17),
(3, 18),
(2, 19),
(2, 20),
(2, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(3, 25),
(1, 26),
(3, 26),
(5, 26);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `Guide`
--
ALTER TABLE `Guide`
 ADD PRIMARY KEY (`GuideID`);

--
-- Indizes für die Tabelle `Stichwort`
--
ALTER TABLE `Stichwort`
 ADD PRIMARY KEY (`StichwortID`);

--
-- Indizes für die Tabelle `Suche`
--
ALTER TABLE `Suche`
 ADD PRIMARY KEY (`StichwortID`,`GuideID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `Guide`
--
ALTER TABLE `Guide`
MODIFY `GuideID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT für Tabelle `Stichwort`
--
ALTER TABLE `Stichwort`
MODIFY `StichwortID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
